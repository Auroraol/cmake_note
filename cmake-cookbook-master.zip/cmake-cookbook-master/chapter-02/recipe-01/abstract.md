In this recipe, we demonstrate how to use CMake to detect the operating system
with an example that does not require compilation of any source code. For
simplicity, we only consider the configuration step.
