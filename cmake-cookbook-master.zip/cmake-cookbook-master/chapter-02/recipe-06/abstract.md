This recipe shows how to enable vectorization to speed up a simple executable
using the [Eigen C++ library](http://eigen.tuxfamily.org) for linear algebra.
