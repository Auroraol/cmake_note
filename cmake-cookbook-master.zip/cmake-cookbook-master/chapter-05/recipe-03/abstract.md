This recipe will show how to use [`add_custom_target`] to add new targets with
custom build goals to the build system.

[`add_custom_target`]: https://cmake.org/cmake/help/latest/command/add_custom_target.html
