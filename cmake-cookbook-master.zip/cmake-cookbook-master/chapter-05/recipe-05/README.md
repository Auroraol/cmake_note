# Running custom commands for specific targets at build time

[`add_custom_command`] can be used to attach execution of additional commands
for specific targets at specific moments during build time. This recipe will
show you how.

[`add_custom_command`]: https://cmake.org/cmake/help/latest/command/add_custom_command.html


- [fortran-example](fortran-example/)
