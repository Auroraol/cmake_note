# Running a custom command at build time: II. Using `add_custom_target`

Running a custom command at build time: II. Using `add_custom_target`


- [cxx-example](cxx-example/)
