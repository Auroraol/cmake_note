We will show how to run a custom command at configure time using the built-in
[`execute_process`] command offered by CMake.

[`execute_process`]: https://cmake.org/cmake/help/latest/command/execute_process.html
