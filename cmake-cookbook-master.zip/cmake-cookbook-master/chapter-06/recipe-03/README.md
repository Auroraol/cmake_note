# Generating source code at build time using Python

In this example, we generate C++ code
by using Python at build time.


- [cxx-example](cxx-example/)
