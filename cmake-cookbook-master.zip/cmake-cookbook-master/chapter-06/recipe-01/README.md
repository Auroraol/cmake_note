# Generating sources at configure time

In this and some of the following recipes, we will illustrate how to generate a
simple source file at configure time. The example generated source file defines
a function to report the build system configuration.


- [fortran-c-example](fortran-c-example/)
