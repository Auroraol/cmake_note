This recipe shows how to use loop construct [`foreach-endforeach`](https://cmake.org/cmake/help/latest/command/foreach.html) in CMake.
