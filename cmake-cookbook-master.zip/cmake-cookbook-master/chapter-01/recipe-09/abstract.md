We will show various mechanism to require and set a specific compiler standard
for our project.
