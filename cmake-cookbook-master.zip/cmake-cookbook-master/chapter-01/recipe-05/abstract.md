We will demonstrate how to make aspects of the build system configurable by
exposing options to the user with the [`option`](https://cmake.org/cmake/help/latest/command/option.html) command.
