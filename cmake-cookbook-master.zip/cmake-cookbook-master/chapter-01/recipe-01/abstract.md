These recipes show how to run CMake to configure and build a simple project.
The project consists of a single source file for a single executable.  The same
project is presented in C++, C and Fortran 90.
