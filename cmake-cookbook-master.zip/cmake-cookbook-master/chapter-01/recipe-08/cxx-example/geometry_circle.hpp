#pragma once

namespace geometry {
namespace area {
double circle(double area);
}
} // namespace geometry
