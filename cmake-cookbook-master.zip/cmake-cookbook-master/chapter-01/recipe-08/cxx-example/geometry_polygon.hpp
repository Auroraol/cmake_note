#pragma once

namespace geometry {
namespace area {
double polygon(int nSides, double side);
}
} // namespace geometry
