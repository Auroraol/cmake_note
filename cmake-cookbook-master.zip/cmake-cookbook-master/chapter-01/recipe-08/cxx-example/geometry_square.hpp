#pragma once

namespace geometry {
namespace area {
double square(double l);
}
} // namespace geometry
