#include "geometry_square.hpp"

#include <cmath>

namespace geometry {
namespace area {
double square(double l) { return std::pow(l, 2); }
} // namespace area
} // namespace geometry
