## Individual Contributors

- Radovan Bast (@bast)
- Roberto Di Remigio (@robertodr)
- Eric Noulard (@TheErk)

This list was obtained 2018-09-23 by running `git shortlog -sn`
