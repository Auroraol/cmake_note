# Defining a unit test and linking against Boost test

Boost test is a popular unit testing framework in the C++ community, and in
this example, we demonstrate how to unit test a simple example code using Boost
test.


- [cxx-example](cxx-example/)
