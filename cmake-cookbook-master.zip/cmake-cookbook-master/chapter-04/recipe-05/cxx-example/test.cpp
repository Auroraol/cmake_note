#include "leaky_implementation.hpp"

int main() {
  int return_code = do_some_work();

  return return_code;
}
