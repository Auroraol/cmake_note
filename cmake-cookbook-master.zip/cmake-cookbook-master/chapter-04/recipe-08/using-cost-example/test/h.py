import sys
import time

# wait for 2.5 seconds
time.sleep(2.5)

# finally report success
sys.exit(0)
