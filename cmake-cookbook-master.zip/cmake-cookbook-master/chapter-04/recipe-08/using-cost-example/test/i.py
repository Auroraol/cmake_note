import sys
import time

# wait for 3.5 seconds
time.sleep(3.5)

# finally report success
sys.exit(0)
