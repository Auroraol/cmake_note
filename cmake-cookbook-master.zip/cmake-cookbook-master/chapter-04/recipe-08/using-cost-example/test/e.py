import sys
import time

# wait for 1.5 seconds
time.sleep(1.5)

# finally report success
sys.exit(0)
