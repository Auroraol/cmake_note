import sys
import time

# wait for 4.5 seconds
time.sleep(4.5)

# finally report success
sys.exit(0)
