In this recipe, we will use CMake in combination with
[Catch2](https://github.com/catchorg/Catch2), to test the summation code
introduced in the previous recipe.

A nice feature of [Catch2](https://github.com/catchorg/Catch2) is the fact that
it can be included in your project as a single-header library, which makes
compilation and updating the framework particularly easy.
