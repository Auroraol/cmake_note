import sys

print("running test b")

# report success
sys.exit(0)
