import sys

# simulate a failing test
sys.exit(1)
