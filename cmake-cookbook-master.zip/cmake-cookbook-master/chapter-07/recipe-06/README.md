# Deprecating functions, macros, and variables

We will show how to deprecate CMake functions, macros, and variables. This can
be quite helpful when modernizing your CMake-based build system.


- [example](example/)
