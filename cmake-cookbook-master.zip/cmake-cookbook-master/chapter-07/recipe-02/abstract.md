We will show how to separate custom CMake code into our own [modules], rather
than keeping everything in a central `CMakeLists.txt`.

[modules]: https://cmake.org/cmake/help/latest/manual/cmake-language.7.html#modules
