We will show how to enhance the example in [Recipe 1, _Code reuse with functions and macros_](../recipe-01)
by letting the function accept _named arguments_. We will use the built-in [`cmake_parse_arguments`] command.

[`cmake_parse_arguments`]: https://cmake.org/cmake/help/latest/command/cmake_parse_arguments.html
