We will introduce the [`find_package`](https://cmake.org/cmake/help/latest/command/find_package.html) CMake command and use it to detect a
working Python interpreter on the system.
