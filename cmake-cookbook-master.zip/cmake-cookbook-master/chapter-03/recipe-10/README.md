# Detecting external libraries: II. Writing a find-module

This recipe shows how to write a `FindZeroMQ.cmake` module to detect the ZeroMQ library.


- [c-example](c-example/)
