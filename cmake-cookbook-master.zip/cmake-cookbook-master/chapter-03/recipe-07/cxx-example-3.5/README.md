To test:
`./linear-algebra 1000` where the integer is the dimension of the matrices/vectors.
