This recipe builds an executable embedding the Python interpreter. We will use
[`find_package`](https://cmake.org/cmake/help/latest/command/find_package.html) to find the Python development headers and library.

Code example copy-pasted from the Python docs on embedding https://docs.python.org/3.5/extending/embedding.html
