simple qt console application.

Qt4

-   Windows

    +   <http://whudoc.qiniudn.com/2016/qt-4.8.6-x64-msvc2010.exe>
    +   set $QT_DIR to this qt release
    +   add to $PATH: `%QT_DIR%/bin` (qmake.exe)
    +   add to $PATH: `%QT_DIR%/lib` (for dlls)
