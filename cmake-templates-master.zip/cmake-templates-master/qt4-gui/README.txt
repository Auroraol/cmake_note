advanced qt gui application.
