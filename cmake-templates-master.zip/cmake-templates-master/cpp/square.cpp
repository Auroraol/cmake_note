#include "square.h"

double square( double x )
{
    return x*x;
}
