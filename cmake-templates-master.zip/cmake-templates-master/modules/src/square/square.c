#include "functions.h"

double square( double x )
{
    return x * x;
}
