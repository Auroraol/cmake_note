#include "functions.h"

double power5( double x )
{
    return cubic(x) * square(x);
}
