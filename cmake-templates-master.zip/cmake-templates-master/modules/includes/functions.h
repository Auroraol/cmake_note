double square( double x );
double cubic( double x );
double power4( double x );
double power5( double x );
