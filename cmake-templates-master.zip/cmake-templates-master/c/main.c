#include <stdio.h>

int main ( int argc, char **argv )
{
    fprintf( stdout, "%s", "Hello World.\n" );
    // getchar();
    return 0;
}
